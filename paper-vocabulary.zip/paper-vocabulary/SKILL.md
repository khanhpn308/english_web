---
name: paper-vocabulary
description: Normalize an English word or short phrase from a scientific paper to its dictionary lemma, explain it in Vietnamese, verify Cambridge US IPA for the lemma and related forms, and append it to the project's daily vocabulary Markdown file. Use when the user invokes /paper-vocabulary, mentions paper-vocabulary, or asks to explain and save academic vocabulary.
---

# Paper Vocabulary

Accept the text after `/paper-vocabulary` as the term to process; do not require a longer prompt. Also accept `$paper-vocabulary` as user-provided text or an explicit request to use this skill. If a source sentence follows the term, treat it as context rather than part of the term. A request to describe, export, or edit the skill itself is not a vocabulary lookup.

## Required outcome

Explain the term in Vietnamese and save the same substantive entry in the current project's vocabulary log. Use recent conversation context to identify the source sentence or paper, but never invent a source location.

## Antigravity / Gemini tools

Use the browser or web-retrieval tools available in Antigravity to verify Cambridge pages, and its file-reading and file-editing tools to maintain the log. This skill does not depend on Codex tool names, MCP servers, or OpenAI configuration.

Use the actual current time converted to `Asia/Bangkok`; do not reuse a date from an old conversation or log. If a terminal with Python is available, one option is:

```bash
python -c "from datetime import datetime; from zoneinfo import ZoneInfo; print(datetime.now(ZoneInfo('Asia/Bangkok')).strftime('%d-%m-%Y'))"
```

When web access is unavailable, explain the term but mark unverified IPA explicitly. When file access is unavailable or a write fails, provide the entry in chat and say it has not been saved; never claim successful logging without reading the saved file.

## Pronunciation source

Verify the American-English IPA against an official Cambridge Dictionary pronunciation or dictionary page. Link that page in both the saved entry and the chat response. Apply the same requirement separately to every related word form included in the entry: look up each form, show its US IPA in the related-forms table, and link its own Cambridge page. Do not infer a related form's pronunciation merely by adding or removing a suffix.

If Cambridge does not list a term or cannot be checked, label that term's IPA `chưa xác minh trên Cambridge` instead of guessing. For a phrase without a Cambridge phrase entry, distinguish word-level pronunciations from a phrase-level transcription. Prefer a small set of genuinely useful related forms whose pronunciations can be verified over a long unverified list.

## Daily log

Find the project root containing `docs/vocabularies/README.md`. Use the `Asia/Bangkok` calendar date and append to:

`docs/vocabularies/DD-MM-YYYY.md`

Create the dated file with a level-one date title if it does not exist. If no existing vocabulary README identifies the project root, use the active workspace root. Preserve all existing entries. Follow the local `docs/vocabularies/README.md` contract. Use the environment's available file-editing tool (a targeted patch when supported) for the edit, then reopen the file and confirm the entry exists.

Before logging, normalize an inflected request to its Cambridge dictionary lemma. This applies to plural nouns, finite verb inflections, past tense, past participles used in passive constructions, and present participles/gerunds. For an inflected noun phrase, normalize the inflected head while preserving the rest of the phrase; for example, `continuous media` becomes `continuous medium`. Do not strip derivational morphology from an independent dictionary headword: an adverb such as `adequately` remains `adequately`.

Use the lemma—not the surface form supplied by the user—in the detailed heading, the `Từ/cụm từ` field, the quick-reference row, and the primary Cambridge IPA. The encountered inflected form may appear only inside the quoted source sentence or an example sentence, where its grammatical function can be explained. Do not create separate entries for singular/plural, active/passive, or tense variants. If the lemma is already present in that day's file, incorporate the new context or example into that entry rather than adding a duplicate.

Maintain a `## Tra cứu nhanh` section with a quick-reference table immediately after the file's level-one date title and before the detailed entries. Use these columns:

| Từ/cụm từ | IPA (US) | Nghĩa ngắn | Ví dụ ngắn | Dịch ví dụ |
|---|---|---|---|---|

The lemma in the first column must be a Markdown link to its level-two detailed-entry heading in the same file. Use the renderer's standard lowercase heading anchor, replacing spaces with hyphens, for example `[Continuous medium](#continuous-medium)`. Keep the meaning concise. Put one natural English sentence in the `Ví dụ ngắn` column, and provide its accurate, standard Cambridge-style Vietnamese translation as a dedicated separate column `Dịch ví dụ` without enclosing the translation in parentheses `( )`. That example sentence may use an inflected form of the lemma.

Whenever adding a detailed entry, add exactly one corresponding row to this table in the same edit. Preserve question order. When improving an existing headword, update its existing row rather than creating another. If an older daily file has detailed entries but no quick-reference table and is being edited, backfill the table for that file. Treat `Tra cứu nhanh` as a reserved structural heading, not a vocabulary entry. Escape any literal `|` characters that would break the Markdown table.

If no project vocabulary directory exists, create `docs/vocabularies/README.md` and the dated file using these same conventions within the current workspace.

## Entry and response format

Do not present the definition as a bullet list. Use this compact structure:

1. A level-two heading containing the lemma.
2. A table containing the lemma, its part of speech, US IPA, stress cue, and Cambridge source.
3. `Ý nghĩa`: a precise Vietnamese explanation, including the important usage nuance.
4. `Trong ngữ cảnh`: the known paper sentence and Vietnamese translation. If no source sentence is known, say so and omit any fabricated citation.
5. `Ví dụ`: one natural English example relevant to the user's research, followed by its Vietnamese translation (without enclosing the translation in parentheses).
6. `Các dạng liên quan`: a compact table with the columns `Dạng từ`, `Từ loại`, `IPA (US)`, `Nghĩa`, `Ví dụ ngắn`, and `Dịch ví dụ`. Prefer derivationally related dictionary headwords rather than repeating ordinary inflections of the main lemma. Link every included form to its own Cambridge source; explicitly mark any IPA that Cambridge does not verify. Put the natural English example in `Ví dụ ngắn` and its accurate Vietnamese translation in the separate `Dịch ví dụ` column without enclosing it in parentheses `( )`.

Keep the explanation accessible to a Vietnamese researcher. Distinguish everyday meaning from the meaning in the supplied scientific context when they differ. Do not overstate a word's technical meaning.

Before finishing, verify that every detailed level-two vocabulary heading has exactly one quick-reference row, every row links to an existing heading, and the row's IPA status remains consistent with the detailed entry.

End the chat response with a short confirmation and a clickable link to the actual dated Markdown file using the environment's supported local-file link format. Include the workspace-relative path if local-file links are unsupported. If saving failed, state that explicitly instead of confirming it.
